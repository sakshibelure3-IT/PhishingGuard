# Backend

The project report documents a Flask backend and MongoDB database. The complete source code as submitted in the report is preserved in `../docs/source-code-from-report.txt` and `../docs/project-report.pdf`.

The report specifies these backend dependencies in `requirements.txt`.
