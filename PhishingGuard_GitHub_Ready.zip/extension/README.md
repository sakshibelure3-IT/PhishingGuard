# Chrome Extension

The report documents the extension structure and source code, including:
- `background.js`
- `content.js`
- `manifest.json`
- `popup.html`
- `popup.js`
- `styles.css`

The submitted source is preserved in `../docs/source-code-from-report.txt` and `../docs/project-report.pdf`.
